# Welcome to The Bin! 🦝

Now that you've thrown some parts into The Bin, it's time to turn that trash into treasure! 🗑️➡️💎

Wire up your parts and write some code to make them work together. If you need
help with a part, click the "?" above it.

If you want to see examples, check here:
https://hack.club/bin-example

You can get help by chatting with other high schoolers on the Hack Club Slack in
the #electronics channel:
👉 https://hackclub.com/slack 👈

Once you're ready build your design IRL, click the "Share" button and submit
your design:
https://hack.club/bin-submit
    